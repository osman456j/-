function goToReport() {
    document.querySelector('.container').classList.add('hidden');
    document.querySelector('.report').classList.remove('hidden');
}

function sendReport() {
    let clientName = document.getElementById("clientName").value;
    let elevatorNumber = document.getElementById("elevatorNumber").value;
    let clientEmail = document.getElementById("clientEmail").value;
    let technicianEmail = document.getElementById("technicianEmail").value;
    let companyEmail = document.getElementById("companyEmail").value;
    let clientPhone = document.getElementById("clientPhone").value;
    let technicianPhone = document.getElementById("technicianPhone").value;
    let companyPhone = document.getElementById("companyPhone").value;

    let checkedParts = [];
    document.querySelectorAll(".part input:checked").forEach((el) => {
        checkedParts.push(el.parentElement.innerText);
    });

    let reportMessage = `تقرير فحص المصعد 🚀\nاسم العميل: ${clientName}\nرقم المصعد: ${elevatorNumber}\n\nالأجزاء المفحوصة:\n${checkedParts.join("\n")}`;

    alert("تم إرسال التقرير بنجاح!");

    let emails = [clientEmail, technicianEmail, companyEmail];
    emails.forEach(email => {
        window.open(`mailto:${email}?subject=تقرير فحص المصعد&body=${encodeURIComponent(reportMessage)}`);
    });

    let phones = [clientPhone, technicianPhone, companyPhone];
    phones.forEach(phone => {
        window.open(`https://wa.me/${phone}?text=${encodeURIComponent(reportMessage)}`);
    });
}
